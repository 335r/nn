import random
import math
import matplotlib.pyplot as plt
import pandas as pd

def generate_gps_coordinates():
    coordinates = []
    for _ in range(10):
        latitude = random.uniform(-90, 90)
        longitude = random.uniform(-180, 180)
        coordinates.append((latitude, longitude))
    return coordinates

def generate_noisy_coordinates(center_coords, radius):
    noisy_coords = []
    for center in center_coords:
        for _ in range(10):
            angle = random.uniform(0, 2 * math.pi)
            noise_distance = random.gauss(radius, radius * 0.1)
            noisy_latitude = center[0] + math.cos(angle) * noise_distance
            noisy_longitude = center[1] + math.sin(angle) * noise_distance
            noisy_latitude = max(min(noisy_latitude, 90), -90)
            noisy_longitude = max(min(noisy_longitude, 180), -180)
            noisy_coords.append((noisy_latitude, noisy_longitude))
    return noisy_coords

# 生成 10 个随机的 GPS 坐标
center_coords = generate_gps_coordinates()

# 生成噪声坐标，中心坐标为生成的 10 个随机坐标
noise_coordinates = generate_noisy_coordinates(center_coords, 5)

# 生成 20 个新的随机误差坐标
error_coordinates = []
for _ in range(20):
    latitude = random.uniform(-90, 90)
    longitude = random.uniform(-180, 180)
    error_coordinates.append((latitude, longitude))

# 打印生成的坐标
print("Center Coordinates:", center_coords)
print("Noise Coordinates:", noise_coordinates)
print("Error Coordinates:", error_coordinates)

# 创建 DataFrame
df_center = pd.DataFrame(center_coords, columns=['Latitude', 'Longitude'])
df_noisy = pd.DataFrame(noise_coordinates, columns=['Latitude', 'Longitude'])
df_error = pd.DataFrame(error_coordinates, columns=['Latitude', 'Longitude'])

# 合并 DataFrame
df_combined = pd.concat([df_center, df_noisy, df_error], ignore_index=True)


# 添加类型标签
df_combined['Type'] = ['Center'] * len(df_center) + ['Noisy'] * len(df_noisy) + ['Error'] * len(df_error)

# 绘制图形
plt.figure(figsize=(10, 6))
plt.scatter(df_center['Longitude'], df_center['Latitude'], color='red',marker='o', label='Center Coordinates')
plt.scatter(df_noisy['Longitude'], df_noisy['Latitude'], color='blue',marker='x', label='Noisy Coordinates', alpha=0.6)
plt.scatter(df_error['Longitude'], df_error['Latitude'], color='green', marker='s',label='Error Coordinates')
plt.xlabel('original_Longitude')
plt.ylabel('original_Latitude')
plt.title('Combined GPS Coordinates')
plt.legend()
plt.grid(True)

# 连接中心坐标
plt.plot(df_center['Longitude'], df_center['Latitude'], color='red', linestyle='-', linewidth=2)

# 连接中心坐标，使用箭头
for i in range(len(df_center) - 1):
    plt.annotate("", xy=(df_center.iloc[i+1]['Longitude'], df_center.iloc[i+1]['Latitude']),
                 xytext=(df_center.iloc[i]['Longitude'], df_center.iloc[i]['Latitude']),
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3", color='red'))

plt.show()

# 保存合并后的 DataFrame 为 Excel 文件
df_combined.to_excel('combined_coordinates.xlsx', index=False)

