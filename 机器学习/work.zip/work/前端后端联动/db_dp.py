import random
import math
import numpy as np
import pandas as pd
from flask import Flask, render_template, jsonify, request
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
import threading
import webbrowser

app = Flask(__name__)

def generate_gps_coordinates(center_count=10):
    coordinates = []
    for _ in range(center_count):
        latitude = random.uniform(-90, 90)
        longitude = random.uniform(-180, 180)
        coordinates.append([longitude, latitude])
    return coordinates


def generate_noisy_coordinates(center_coords, radius=5.0):
    noisy_coords = []
    for center in center_coords:
        for _ in range(10):
            angle = random.uniform(0, 2 * math.pi)
            noise_distance = random.gauss(radius, radius * 0.1)
            noisy_latitude = center[1] + math.cos(angle) * noise_distance
            noisy_longitude = center[0] + math.sin(angle) * noise_distance
            noisy_latitude = max(min(noisy_latitude, 90), -90)
            noisy_longitude = max(min(noisy_longitude, 180), -180)
            noisy_coords.append([noisy_longitude, noisy_latitude])
    return noisy_coords


def generate_error_coordinates(error_count=20):
    error_coords = []
    for _ in range(error_count):
        latitude = random.uniform(-90, 90)
        longitude = random.uniform(-180, 180)
        error_coords.append([longitude, latitude])
    return error_coords


def douglas_peucker(points, tolerance=2.5):
    """Douglas-Peucker轨迹压缩算法"""
    if len(points) <= 2:
        return points

    # 找到离线段最远的点
    max_dist = 0
    max_index = 0
    start, end = points[0], points[-1]

    for i in range(1, len(points) - 1):
        dist = perpendicular_distance(points[i], start, end)
        if dist > max_dist:
            max_dist = dist
            max_index = i

    # 如果最远点大于阈值，则递归压缩
    if max_dist > tolerance:
        left = douglas_peucker(points[: max_index + 1], tolerance)
        right = douglas_peucker(points[max_index:], tolerance)
        return left[:-1] + right
    else:
        return [start, end]


def perpendicular_distance(point, line_start, line_end):
    """计算点到线段的垂直距离"""
    x, y = point
    x1, y1 = line_start
    x2, y2 = line_end

    if x1 == x2 and y1 == y2:
        return math.sqrt((x - x1) ** 2 + (y - y1) ** 2)

    area = abs((x2 - x1) * (y1 - y) - (x1 - x) * (y2 - y1))
    line_len = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    return area / line_len


@app.route("/")
def index():
    """主页面"""
    return render_template("index.html")


@app.route("/generate_data", methods=["POST"])
def generate_data():
    """生成GPS数据"""
    data = request.json
    center_count = data.get("centerCount", 10)
    noise_radius = data.get("noiseRadius", 5.0)
    error_count = data.get("errorCount", 20)

    # 生成数据
    center_coords = generate_gps_coordinates(center_count)
    noise_coords = generate_noisy_coordinates(center_coords, noise_radius)
    error_coords = generate_error_coordinates(error_count)

    # 返回数据
    return jsonify(
        {
            "center_coords": center_coords,
            "noise_coords": noise_coords,
            "error_coords": error_coords,
        }
    )


@app.route("/process_data", methods=["POST"])
def process_data():
    """处理数据（聚类和压缩）"""
    data = request.json
    center_coords = data["center_coords"]
    noise_coords = data["noise_coords"]
    error_coords = data["error_coords"]
    eps = data.get("eps", 0.5)
    min_samples = data.get("minSamples", 6)
    tolerance = data.get("tolerance", 2.5)

    # 合并所有点用于聚类
    all_points = center_coords + noise_coords + error_coords
    types = (
        ["center"] * len(center_coords)
        + ["noise"] * len(noise_coords)
        + ["error"] * len(error_coords)
    )

    # 标准化
    scaler = StandardScaler()
    scaled_points = scaler.fit_transform(all_points)

    # DBSCAN聚类
    db = DBSCAN(eps=eps, min_samples=min_samples).fit(scaled_points)
    labels = db.labels_.tolist()

    # 计算统计信息
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise = list(labels).count(-1)

    # 轨迹压缩
    compressed_points = douglas_peucker(center_coords, tolerance)

    # 计算压缩率
    compression_ratio = 1 - len(compressed_points) / len(center_coords)

    return jsonify(
        {
            "labels": labels,
            "n_clusters": n_clusters,
            "n_noise": n_noise,
            "compressed_points": compressed_points,
            "compression_ratio": compression_ratio,
            "types": types,  # 返回每个点的类型
        }
    )


def open_browser():
    """在默认浏览器中打开应用"""
    webbrowser.open_new("http://127.0.0.1:5000/")


if __name__ == "__main__":
    # 在单独的线程中打开浏览器
    threading.Thread(target=open_browser).start()
    app.run(debug=False)
