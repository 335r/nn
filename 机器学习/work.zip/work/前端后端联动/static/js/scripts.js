// 全局变量
let centerCoords = [];
let noiseCoords = [];
let errorCoords = [];
let dbscanLabels = [];
let compressedPoints = [];

// 初始化图表
const originalCtx = document.getElementById('originalChart').getContext('2d');
const clusterCtx = document.getElementById('clusterChart').getContext('2d');
const compressionCtx = document.getElementById('compressionChart').getContext('2d');
const comparisonCtx = document.getElementById('comparisonChart').getContext('2d');

// 初始化图表实例
let originalChart, clusterChart, compressionChart, comparisonChart;

// 初始化
document.addEventListener('DOMContentLoaded', function () {
    initSliders();
    generateData();
});

// 初始化滑块事件
function initSliders() {
    document.getElementById('centerCount').addEventListener('input', function () {
        document.getElementById('centerCountValue').textContent = this.value;
    });

    document.getElementById('noiseRadius').addEventListener('input', function () {
        document.getElementById('noiseRadiusValue').textContent = parseFloat(this.value).toFixed(1);
    });

    document.getElementById('errorCount').addEventListener('input', function () {
        document.getElementById('errorCountValue').textContent = this.value;
    });

    document.getElementById('eps').addEventListener('input', function () {
        document.getElementById('epsValue').textContent = parseFloat(this.value).toFixed(1);
    });

    document.getElementById('minSamples').addEventListener('input', function () {
        document.getElementById('minSamplesValue').textContent = this.value;
    });

    document.getElementById('tolerance').addEventListener('input', function () {
        document.getElementById('toleranceValue').textContent = parseFloat(this.value).toFixed(1);
    });

    document.getElementById('generateBtn').addEventListener('click', function () {
        generateData();
    });

    document.getElementById('processBtn').addEventListener('click', function () {
        processData();
    });
}

// 生成数据
function generateData() {
    const centerCount = parseInt(document.getElementById('centerCount').value);
    const noiseRadius = parseFloat(document.getElementById('noiseRadius').value);
    const errorCount = parseInt(document.getElementById('errorCount').value);

    // 发送请求到后端生成数据
    fetch('/generate_data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            centerCount: centerCount,
            noiseRadius: noiseRadius,
            errorCount: errorCount
        })
    })
        .then(response => response.json())
        .then(data => {
            centerCoords = data.center_coords.map(coord => ({ x: coord[0], y: coord[1] }));
            noiseCoords = data.noise_coords.map(coord => ({ x: coord[0], y: coord[1] }));
            errorCoords = data.error_coords.map(coord => ({ x: coord[0], y: coord[1] }));

            // 更新统计信息
            document.getElementById('originalPoints').textContent = centerCoords.length + noiseCoords.length + errorCoords.length;

            // 重置处理结果
            dbscanLabels = [];
            compressedPoints = [];
            document.getElementById('clusterCount').textContent = '0';
            document.getElementById('noisePoints').textContent = '0';
            document.getElementById('compressionRatio').textContent = '0%';

            // 重新渲染图表
            renderCharts();
        })
        .catch(error => console.error('生成数据错误:', error));
}

// 处理数据（聚类和压缩）
function processData() {
    // 准备数据
    const eps = parseFloat(document.getElementById('eps').value);
    const minSamples = parseInt(document.getElementById('minSamples').value);
    const tolerance = parseFloat(document.getElementById('tolerance').value);

    // 将数据转换为后端需要的格式
    const center_coords = centerCoords.map(coord => [coord.x, coord.y]);
    const noise_coords = noiseCoords.map(coord => [coord.x, coord.y]);
    const error_coords = errorCoords.map(coord => [coord.x, coord.y]);

    // 发送请求到后端处理数据
    fetch('/process_data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            center_coords: center_coords,
            noise_coords: noise_coords,
            error_coords: error_coords,
            eps: eps,
            minSamples: minSamples,
            tolerance: tolerance
        })
    })
        .then(response => response.json())
        .then(data => {
            dbscanLabels = data.labels;
            compressedPoints = data.compressed_points.map(coord => ({ x: coord[0], y: coord[1] }));

            // 更新统计信息
            document.getElementById('clusterCount').textContent = data.n_clusters;
            document.getElementById('noisePoints').textContent = data.n_noise;
            document.getElementById('compressionRatio').textContent = Math.round(data.compression_ratio * 100) + '%';

            // 重新渲染图表
            renderCharts();
        })
        .catch(error => console.error('处理数据错误:', error));
}

// 渲染所有图表
function renderCharts() {
    renderOriginalChart();
    renderClusterChart();
    renderCompressionChart();
    renderComparisonChart();
}

// 渲染原始数据图表
function renderOriginalChart() {
    if (originalChart) originalChart.destroy();

    // 准备数据集
    const datasets = [
        {
            label: '中心点',
            data: centerCoords,
            backgroundColor: 'rgba(255, 99, 132, 0.8)',
            pointRadius: 6,
            pointHoverRadius: 8
        },
        {
            label: '噪声点',
            data: noiseCoords,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            pointRadius: 4,
            pointHoverRadius: 6
        },
        {
            label: '错误点',
            data: errorCoords,
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
            pointRadius: 4,
            pointHoverRadius: 6
        }
    ];

    // 创建图表
    originalChart = new Chart(originalCtx, {
        type: 'scatter',
        data: { datasets },
        options: chartOptions('经度', '纬度')
    });

    // 添加连接线（箭头）
    setTimeout(() => {
        addArrowsToChart(originalChart, centerCoords, 'rgba(255, 99, 132, 0.7)');
    }, 500);
}

// 渲染聚类结果图表
function renderClusterChart() {
    if (clusterChart) clusterChart.destroy();

    // 如果没有处理过数据，则直接返回
    if (dbscanLabels.length === 0) {
        clusterChart = new Chart(clusterCtx, {
            type: 'scatter',
            data: { datasets: [] },
            options: chartOptions('经度', '纬度')
        });
        return;
    }

    // 准备数据集
    const allPoints = [
        ...centerCoords.map(p => ({ ...p, type: 'center' })),
        ...noiseCoords.map(p => ({ ...p, type: 'noise' })),
        ...errorCoords.map(p => ({ ...p, type: 'error' }))
    ];

    // 按聚类分组
    const clusters = {};
    allPoints.forEach((point, i) => {
        const clusterId = dbscanLabels[i];
        if (!clusters[clusterId]) {
            clusters[clusterId] = [];
        }
        clusters[clusterId].push(point);
    });

    // 创建数据集
    const clusterColors = [
        '#4e89ff', '#ff6b6b', '#51cf66', '#fcc419',
        '#be4bdb', '#20c997', '#ff922b', '#748ffc',
        '#ff8787', '#3bc9db', '#ffe066', '#da77f2'
    ];

    const datasets = [];

    // 添加聚类点
    Object.entries(clusters).forEach(([clusterId, points]) => {
        if (clusterId === '-1') {
            // 噪声点
            datasets.push({
                label: '噪声点',
                data: points,
                backgroundColor: 'rgba(0, 0, 0, 0.7)',
                pointRadius: 4,
                pointHoverRadius: 6
            });
        } else {
            // 聚类点
            const colorIndex = (parseInt(clusterId) - 1) % clusterColors.length;
            datasets.push({
                label: `聚类 ${clusterId}`,
                data: points,
                backgroundColor: clusterColors[colorIndex],
                pointRadius: 5,
                pointHoverRadius: 7
            });
        }
    });

    // 创建图表
    clusterChart = new Chart(clusterCtx, {
        type: 'scatter',
        data: { datasets },
        options: chartOptions('经度', '纬度')
    });

    // 添加连接线（箭头）
    setTimeout(() => {
        addArrowsToChart(clusterChart, centerCoords, 'rgba(255, 99, 132, 0.7)');
    }, 500);
}

// 渲染轨迹压缩图表
function renderCompressionChart() {
    if (compressionChart) compressionChart.destroy();

    // 如果没有处理过数据，则使用原始中心点
    if (compressedPoints.length === 0) {
        compressedPoints = [...centerCoords];
    }

    // 准备数据集
    const datasets = [
        {
            label: '原始中心点',
            data: centerCoords,
            backgroundColor: 'rgba(255, 99, 132, 0.8)',
            pointRadius: 6,
            pointHoverRadius: 8
        },
        {
            label: '压缩关键点',
            data: compressedPoints,
            backgroundColor: 'rgba(54, 162, 235, 0.8)',
            pointRadius: 7,
            pointHoverRadius: 9,
            pointStyle: 'rectRot'
        }
    ];

    // 创建图表
    compressionChart = new Chart(compressionCtx, {
        type: 'scatter',
        data: { datasets },
        options: chartOptions('经度', '纬度')
    });

    // 添加连接线（箭头）
    setTimeout(() => {
        addArrowsToChart(compressionChart, compressedPoints, 'rgba(54, 162, 235, 0.7)');
    }, 500);
}

// 渲染对比图表
function renderComparisonChart() {
    if (comparisonChart) comparisonChart.destroy();

    // 如果没有处理过数据，则使用原始中心点
    if (compressedPoints.length === 0) {
        compressedPoints = [...centerCoords];
    }

    // 准备数据集
    const datasets = [
        {
            label: '原始轨迹',
            data: centerCoords,
            backgroundColor: 'rgba(255, 99, 132, 0.6)',
            pointRadius: 5,
            pointHoverRadius: 7,
            showLine: true,
            borderColor: 'rgba(255, 99, 132, 0.8)',
            borderWidth: 2,
            fill: false
        },
        {
            label: '压缩轨迹',
            data: compressedPoints,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            pointRadius: 6,
            pointHoverRadius: 8,
            pointStyle: 'rectRot',
            showLine: true,
            borderColor: 'rgba(54, 162, 235, 0.8)',
            borderWidth: 2,
            borderDash: [5, 5],
            fill: false
        }
    ];

    // 创建图表
    comparisonChart = new Chart(comparisonCtx, {
        type: 'scatter',
        data: { datasets },
        options: chartOptions('经度', '纬度')
    });
}

// 图表通用配置
function chartOptions(xLabel, yLabel) {
    return {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: {
                title: {
                    display: true,
                    text: xLabel,
                    color: 'rgba(255, 255, 255, 0.7)'
                },
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                    color: 'rgba(255, 255, 255, 0.7)'
                }
            },
            y: {
                title: {
                    display: true,
                    text: yLabel,
                    color: 'rgba(255, 255, 255, 0.7)'
                },
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                    color: 'rgba(255, 255, 255, 0.7)'
                }
            }
        },
        plugins: {
            legend: {
                labels: {
                    color: 'rgba(255, 255, 255, 0.8)'
                }
            },
            tooltip: {
                callbacks: {
                    label: function (context) {
                        return `(${context.parsed.x.toFixed(4)}, ${context.parsed.y.toFixed(4)})`;
                    }
                }
            }
        },
        animation: {
            duration: 1000,
            easing: 'easeOutQuart'
        }
    };
}

// 向图表添加箭头
function addArrowsToChart(chart, points, color) {
    const ctx = chart.ctx;
    const xAxis = chart.scales.x;
    const yAxis = chart.scales.y;

    ctx.save();
    ctx.beginPath();
    ctx.lineWidth = 2;
    ctx.strokeStyle = color;

    // 绘制连接线
    for (let i = 0; i < points.length - 1; i++) {
        const startX = xAxis.getPixelForValue(points[i].x);
        const startY = yAxis.getPixelForValue(points[i].y);
        const endX = xAxis.getPixelForValue(points[i + 1].x);
        const endY = yAxis.getPixelForValue(points[i + 1].y);

        // 绘制线
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);

        // 绘制箭头
        const angle = Math.atan2(endY - startY, endX - startX);
        ctx.save();
        ctx.translate(endX, endY);
        ctx.rotate(angle);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-10, -5);
        ctx.lineTo(-10, 5);
        ctx.closePath();
        ctx.fillStyle = color;
        ctx.fill();
        ctx.restore();
    }

    ctx.stroke();
    ctx.restore();
}