import random
import math
import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
from shapely.geometry import Point, LineString
import matplotlib.pyplot as plt

def generate_gps_coordinates():

    coordinates = []
    for _ in range(10):
        latitude = random.uniform(-90, 90)
        longitude = random.uniform(-180, 180)
        coordinates.append((latitude, longitude))
    return coordinates

def generate_noisy_coordinates(center_coords, radius):
    noisy_coords = []
    for center in center_coords:
        for _ in range(10):
            angle = random.uniform(0, 2 * math.pi)
            noise_distance = random.gauss(radius, radius * 0.1)
            noisy_latitude = center[0] + math.cos(angle) * noise_distance
            noisy_longitude = center[1] + math.sin(angle) * noise_distance
            noisy_latitude = max(min(noisy_latitude, 90), -90)
            noisy_longitude = max(min(noisy_longitude, 180), -180)
            noisy_coords.append((noisy_latitude, noisy_longitude))
    return noisy_coords

# 生成 10 个随机的 GPS 坐标
center_coords = generate_gps_coordinates()

# 生成噪声坐标，中心坐标为生成的 10 个随机坐标
noise_coordinates = generate_noisy_coordinates(center_coords, 5)

# 生成 20 个新的随机误差坐标
error_coordinates = []
for _ in range(20):
    latitude = random.uniform(-90, 90)
    longitude = random.uniform(-180, 180)
    error_coordinates.append((latitude, longitude))

# 打印生成的坐标
print("Center Coordinates:", center_coords)
print("Noise Coordinates:", noise_coordinates)
print("Error Coordinates:", error_coordinates)

# 创建 DataFrame
df_center = pd.DataFrame(center_coords, columns=['Latitude', 'Longitude'])
df_noisy = pd.DataFrame(noise_coordinates, columns=['Latitude', 'Longitude'])
df_error = pd.DataFrame(error_coordinates, columns=['Latitude', 'Longitude'])

# 合并 DataFrame
df_combined = pd.concat([df_center, df_noisy, df_error], ignore_index=True)


# 添加类型标签
df_combined['Type'] = ['Center'] * len(df_center) + ['Noisy'] * len(df_noisy) + ['Error'] * len(df_error)

# 绘制图形
plt.figure(figsize=(10, 6))
plt.scatter(df_center['Longitude'], df_center['Latitude'], color='red',marker='o', label='Center Coordinates')
plt.scatter(df_noisy['Longitude'], df_noisy['Latitude'], color='blue', marker='x',label='Noisy Coordinates', alpha=0.6)
plt.scatter(df_error['Longitude'], df_error['Latitude'], color='green', marker='s',label='Error Coordinates')
plt.xlabel('original_Longitude')
plt.ylabel('original_Latitude')
plt.title('Combined GPS Coordinates')
plt.legend()
plt.grid(True)

# 连接中心坐标
plt.plot(df_center['Longitude'], df_center['Latitude'], color='red', linestyle='-', linewidth=2)

# 连接中心坐标，使用箭头
for i in range(len(df_center) - 1):
    plt.annotate("", xy=(df_center.iloc[i+1]['Longitude'], df_center.iloc[i+1]['Latitude']),
                 xytext=(df_center.iloc[i]['Longitude'], df_center.iloc[i]['Latitude']),
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3", color='red'))

plt.show()

# 保存合并后的 DataFrame 为 Excel 文件
df_combined.to_excel('combined_coordinates.xlsx', index=False)

# 读取Excel文件中的数据
df_center = pd.read_excel('combined_coordinates.xlsx')
center_coords = df_center[df_center['Type'] == 'Center'][['Longitude','Latitude']].values
noise_coords = df_center[df_center['Type'] == 'Noisy'][['Longitude','Latitude']].values
error_coords = df_center[df_center['Type'] == 'Error'][['Longitude','Latitude']].values

# 将所有坐标合并到一个 DataFrame 中
all_coordinates = np.concatenate((center_coords, noise_coords, error_coords))
df_all = pd.DataFrame(all_coordinates, columns=['Longitude','Latitude'])

# 初始化标准化器
scaler = StandardScaler()

# 对数据进行标准化处理
df_scaled = pd.DataFrame(scaler.fit_transform(df_all), columns=['Latitude', 'Longitude'])

# 使用 DBSCAN 进行聚类
db = DBSCAN(eps=0.5, min_samples=6).fit(df_scaled)
labels = db.labels_

# 计算 Davies-Bouldin 指数
db_index = metrics.davies_bouldin_score(df_scaled, labels)
print("DB指数：%0.3f" % db_index)

# 创建一个布尔掩码，标记核心样本点
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True

# 获取每个样本点的聚类标签
labels = db.labels_
print(labels)

# 统计聚类结果的一些信息
n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
n_noise_ = list(labels).count(-1)
print('估计的聚类数量：%d' % n_clusters_)
print('估计的噪声点数量：%d' % n_noise_)

# 绘制DBSCAN聚类结果
# plt.figure(figsize=(10, 8))
unique_labels = set(labels)  # 聚类得到的标签
colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]  # 生成一组颜色
# colors = ['blue', 'green', 'red', 'cyan', 'magenta', 'yellow', 'black']
for k, col in zip(unique_labels, colors):
    if k == -1:
        col = (0, 0, 0, 1)  # 噪声点使用黑色

    class_member_mask = (labels == k)

    # 绘制核心样本点（大圆点）
    xy1 = df_scaled[class_member_mask & core_samples_mask]
    plt.plot(xy1.iloc[:, 0], xy1.iloc[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=8)

    # 绘制非核心样本点（小圆点）
    xy2 = df_scaled[class_member_mask & ~core_samples_mask]
    plt.plot(xy2.iloc[:, 0], xy2.iloc[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=6)

# 创建DataFrame并将它们合并，最后绘制了一个散点图来可视化聚类结果
#创建中心点的 DataFrame：
df_center2 = pd.DataFrame(center_coords, columns=['x', 'y'])
df_center2['type'] = 'center'

# 噪声点（labels == -1）
#识别噪声点并创建 DataFrame
noise_mask = labels == -1
df_noise2 = pd.DataFrame(df_scaled[noise_mask], columns=['x', 'y'])
df_noise2['type'] = 'noise'

# 错误分类的点（这里我们假设是那些不是核心点但被错误分类的点）
error_mask = ~core_samples_mask
df_error2 = pd.DataFrame(df_scaled[error_mask], columns=['x', 'y'])
df_error2['type'] = 'error'

# 合并DataFrame
df_concatenated = pd.concat([df_center2, df_noise2, df_error2], ignore_index=True)

# 绘制散点图
plt.figure(figsize=(10, 6))
for label in df_concatenated['type'].unique():
    subset = df_concatenated[df_concatenated['type'] == label]
    plt.scatter(subset['x'], subset['y'], label=label)

# 连接中心坐标点，使用箭头
for i in range(len(df_center2) - 1):
    plt.annotate("", xy=(df_center2.iloc[i+1]['x'], df_center2.iloc[i+1]['y']),
                 xytext=(df_center2.iloc[i]['x'], df_center2.iloc[i]['y']),
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3", color='red'))

# 添加图例
plt.legend()

# 添加标题和轴标签
plt.title('Cluster Visualization with Arrows')
plt.xlabel('DBSCAN_Longitude')
plt.ylabel('DBSCAN_Latitude')

# 显示图形
plt.grid(True)
plt.show()

# 保存DataFrame为Excel文件
df_concatenated.to_excel('combined_coordinates_with_types.xlsx', index=False)

#Douglas-Peucker算法（几何压缩）
class Douglas_Peuker:
    def __init__(self, points, tolerance):
        self.points = points
        self.tolerance = tolerance
        self.indexes = [0, len(points) - 1]  # 确保起点和终点始终被保留

    def d(self, point, segment):
        """
        计算点到线段的垂直距离
        """
        if segment.is_empty:
            return 0
        x, y = segment.centroid.coords[0]
        return point.distance(Point(x, y))

    def compress(self):
        """
        递归实现Douglas-Peucker算法
        """
        self._simplify(0, len(self.points) - 1)
        return [self.points[i] for i in self.indexes]

    def _simplify(self, start, end):
        if start == end or start + 1 == end:
            return
        segment = LineString(self.points[start:end+1])
        max_distance = 0
        index = start
        for i in range(start + 1, end):
            distance = self.d(Point(self.points[i]), segment)
            if distance > max_distance:
                max_distance = distance
                index = i
        if max_distance > self.tolerance:
            self.indexes.append(index)
            self._simplify(start, index)
            self._simplify(index, end)

points = center_coords
# 压缩轨迹
dpg = Douglas_Peuker(points, 2.5)
compressed_points = dpg.compress()

# 创建DataFrame
df_center = pd.DataFrame(center_coords, columns=['x', 'y'])
df_center['type'] = 'center'
compressed_df = pd.DataFrame(compressed_points, columns=['x', 'y'])
compressed_df['type'] = 'compressed'

# 合并DataFrame
merged_df = pd.concat([df_center, compressed_df], ignore_index=True)

# 绘制原始轨迹和压缩后的轨迹
plt.figure(figsize=(10, 6))
# 绘制中心坐标点
plt.plot(df_center['x'], df_center['y'], 'ro-', label='Center Coordinates')

# 绘制压缩后的点，并用箭头连接
for i in range(len(compressed_df) - 1):
    plt.annotate("", xy=compressed_df.iloc[i+1][['x', 'y']].values, xytext=compressed_df.iloc[i][['x', 'y']].values,
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3", color='b'))

plt.grid(True)
plt.legend()
plt.title('Center Coordinates and Compressed Points with Arrows')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.show()

# 保存合并后的DataFrame为Excel文件
merged_df.to_excel('combined1_coordinates.xlsx', index=False)

# 使用Douglas-Peucker算法对中心坐标进行压缩
dpg = Douglas_Peuker(center_coords, 2.5)
compressed_points = dpg.compress()

# 创建DataFrame
df_center = pd.DataFrame(center_coords, columns=['x', 'y'])
df_center['type'] = 'center'
compressed_df = pd.DataFrame(compressed_points, columns=['x', 'y'])
compressed_df['type'] = 'compressed'

# 合并DataFrame
merged_df = pd.concat([df_center, compressed_df], ignore_index=True)

# 压缩后的轨迹
# 绘制压缩后的轨迹和中心点
plt.figure(figsize=(10, 6))

# 绘制压缩后的点，并用箭头连接
for i in range(len(compressed_df) - 1):
    plt.annotate("", xy=(compressed_df.iloc[i+1]['x'], compressed_df.iloc[i+1]['y']),
                 xytext=(compressed_df.iloc[i]['x'], compressed_df.iloc[i]['y']),
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3", color='b'))

# 绘制原始中心点
plt.plot(df_center['x'], df_center['y'], 'ro', label='Original Center Points')
plt.grid(True)
plt.legend()
plt.title('Compressed Points and Original Center Points with Arrows')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.show()

# 保存合并后的DataFrame为Excel文件
merged_df.to_excel('compressed_points.xlsx', index=False)