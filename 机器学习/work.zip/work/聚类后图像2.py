import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# 读取Excel文件中的数据
df_center = pd.read_excel('combined_coordinates.xlsx')
center_coords = df_center[df_center['Type'] == 'Center'][['Longitude','Latitude']].values
noise_coords = df_center[df_center['Type'] == 'Noisy'][['Longitude','Latitude']].values
error_coords = df_center[df_center['Type'] == 'Error'][['Longitude','Latitude']].values

# 将所有坐标合并到一个 DataFrame 中
all_coordinates = np.concatenate((center_coords, noise_coords, error_coords))
df_all = pd.DataFrame(all_coordinates, columns=['Longitude','Latitude'])

# 初始化标准化器
scaler = StandardScaler()

# 对数据进行标准化处理
df_scaled = pd.DataFrame(scaler.fit_transform(df_all), columns=['Latitude', 'Longitude'])

# 使用 DBSCAN 进行聚类
db = DBSCAN(eps=0.5, min_samples=6).fit(df_scaled)
labels = db.labels_

# 计算 Davies-Bouldin 指数
db_index = metrics.davies_bouldin_score(df_scaled, labels)
print("DB指数：%0.3f" % db_index)

# 创建一个布尔掩码，标记核心样本点
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True

# 获取每个样本点的聚类标签
labels = db.labels_
print(labels)

# 统计聚类结果的一些信息
n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
n_noise_ = list(labels).count(-1)
print('估计的聚类数量：%d' % n_clusters_)
print('估计的噪声点数量：%d' % n_noise_)

# 绘制DBSCAN聚类结果
# plt.figure(figsize=(10, 8))
unique_labels = set(labels)  # 聚类得到的标签
colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]  # 生成一组颜色
# colors = ['blue', 'green', 'red', 'cyan', 'magenta', 'yellow', 'black']
for k, col in zip(unique_labels, colors):
    if k == -1:
        col = (0, 0, 0, 1)  # 噪声点使用黑色

    class_member_mask = (labels == k)

    # 绘制核心样本点（大圆点）
    xy1 = df_scaled[class_member_mask & core_samples_mask]
    plt.plot(xy1.iloc[:, 0], xy1.iloc[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=8)

    # 绘制非核心样本点（小圆点）
    xy2 = df_scaled[class_member_mask & ~core_samples_mask]
    plt.plot(xy2.iloc[:, 0], xy2.iloc[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=6)

# 创建DataFrame并将它们合并，最后绘制了一个散点图来可视化聚类结果
#创建中心点的 DataFrame：
df_center2 = pd.DataFrame(center_coords, columns=['x', 'y'])
df_center2['type'] = 'center'

# 噪声点（labels == -1）
#识别噪声点并创建 DataFrame
noise_mask = labels == -1
df_noise2 = pd.DataFrame(df_scaled[noise_mask], columns=['x', 'y'])
df_noise2['type'] = 'noise'

# 错误分类的点（这里我们假设是那些不是核心点但被错误分类的点）
error_mask = ~core_samples_mask
df_error2 = pd.DataFrame(df_scaled[error_mask], columns=['x', 'y'])
df_error2['type'] = 'error'

# 合并DataFrame
df_concatenated = pd.concat([df_center2, df_noise2, df_error2], ignore_index=True)

# 绘制散点图
plt.figure(figsize=(10, 6))
for label in df_concatenated['type'].unique():
    subset = df_concatenated[df_concatenated['type'] == label]
    plt.scatter(subset['x'], subset['y'], label=label)

# 连接中心坐标点，使用箭头
for i in range(len(df_center2) - 1):
    plt.annotate("", xy=(df_center2.iloc[i+1]['x'], df_center2.iloc[i+1]['y']),
                 xytext=(df_center2.iloc[i]['x'], df_center2.iloc[i]['y']),
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3", color='red'))

# 添加图例
plt.legend()

# 添加标题和轴标签
plt.title('Cluster Visualization with Arrows')
plt.xlabel('DBSCAN_Longitude')
plt.ylabel('DBSCAN_Latitude')
plt.grid(True)
# 显示图形
plt.show()

# 保存DataFrame为Excel文件
df_concatenated.to_excel('combined_coordinates_with_types.xlsx', index=False)
