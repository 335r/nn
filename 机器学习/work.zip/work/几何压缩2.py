import pandas as pd
from shapely.geometry import Point, LineString
import matplotlib.pyplot as plt
from 聚类后图像2 import center_coords

# Douglas-Peucker算法（几何压缩）
class Douglas_Peuker:
    def __init__(self, points, tolerance):
        self.points = points
        self.tolerance = tolerance
        self.indexes = [0, len(points) - 1]  # 确保起点和终点始终被保留

    def d(self, point, segment):
        """
        计算点到线段的垂直距离
        """
        if segment.is_empty:
            return 0
        x, y = segment.centroid.coords[0]
        return point.distance(Point(x, y))

    def compress(self):
        """
        递归实现Douglas-Peucker算法
        """
        self._simplify(0, len(self.points) - 1)
        return [self.points[i] for i in self.indexes]

    def _simplify(self, start, end):
        if start == end or start + 1 == end:
            return
        segment = LineString(self.points[start:end+1])
        max_distance = 0
        index = start
        for i in range(start + 1, end):
            distance = self.d(Point(self.points[i]), segment)
            if distance > max_distance:
                max_distance = distance
                index = i
        if max_distance > self.tolerance:
            self.indexes.append(index)
            self._simplify(start, index)
            self._simplify(index, end)

points = center_coords
# 压缩轨迹
dpg = Douglas_Peuker(points, 2.5)
compressed_points = dpg.compress()

# 创建DataFrame
df_center = pd.DataFrame(center_coords, columns=['x', 'y'])
df_center['type'] = 'center'
compressed_df = pd.DataFrame(compressed_points, columns=['x', 'y'])
compressed_df['type'] = 'compressed'

# 合并DataFrame
merged_df = pd.concat([df_center, compressed_df], ignore_index=True)

# 绘制原始轨迹和压缩后的轨迹
plt.figure(figsize=(10, 6))
# 绘制中心坐标点
plt.plot(df_center['x'], df_center['y'], 'ro-', label='Center Coordinates')

# 绘制压缩后的点，并用箭头连接
for i in range(len(compressed_df) - 1):
    plt.annotate("", xy=compressed_df.iloc[i+1][['x', 'y']].values, xytext=compressed_df.iloc[i][['x', 'y']].values,
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3", color='b'))

plt.grid(True)
plt.legend()
plt.title('Center Coordinates and Compressed Points with Arrows')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.show()

# 保存合并后的DataFrame为Excel文件
merged_df.to_excel('combined1_coordinates.xlsx', index=False)
