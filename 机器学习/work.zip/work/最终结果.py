import pandas as pd
import matplotlib.pyplot as plt
from 聚类后图像2 import center_coords
from 几何压缩2 import Douglas_Peuker

# 使用Douglas-Peucker算法对中心坐标进行压缩
dpg = Douglas_Peuker(center_coords, 2.5)
compressed_points = dpg.compress()

# 创建DataFrame
df_center = pd.DataFrame(center_coords, columns=['x', 'y'])
df_center['type'] = 'center'
compressed_df = pd.DataFrame(compressed_points, columns=['x', 'y'])
compressed_df['type'] = 'compressed'

# 合并DataFrame
merged_df = pd.concat([df_center, compressed_df], ignore_index=True)

# 压缩后的轨迹
# 绘制压缩后的轨迹和中心点
plt.figure(figsize=(10, 6))

# 绘制压缩后的点，并用箭头连接
for i in range(len(compressed_df) - 1):
    plt.annotate("", xy=(compressed_df.iloc[i+1]['x'], compressed_df.iloc[i+1]['y']),
                 xytext=(compressed_df.iloc[i]['x'], compressed_df.iloc[i]['y']),
                 arrowprops=dict(arrowstyle="->", connectionstyle="arc3", color='b'))

# 绘制原始中心点
plt.plot(df_center['x'], df_center['y'], 'ro', label='Original Center Points')
plt.grid(True)
plt.legend()
plt.title('Compressed Points and Original Center Points with Arrows')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.show()

# 保存合并后的DataFrame为Excel文件
merged_df.to_excel('compressed_points.xlsx', index=False)